#!/usr/bin/env python3
"""Create the immutable pre-confirmatory manuscript evidence manifest."""

from __future__ import annotations

import hashlib
import json
import pathlib
import subprocess
import tempfile
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parent.parent
ORIGINAL_PAPER = pathlib.Path(
    "/mnt/data/kleffy-ai-workspace/aib-labs/projects/crucible-paper"
)
PROTOCOL_REPO = pathlib.Path(
    "/mnt/data/kleffy-ai-workspace/aib-labs/projects/epistemic-crucible-public"
)


def run(*args: str, cwd: pathlib.Path) -> str:
    completed = subprocess.run(args, cwd=cwd, check=True, capture_output=True, text=True)
    return completed.stdout.strip()


def run_lines(*args: str, cwd: pathlib.Path) -> list[str]:
    completed = subprocess.run(args, cwd=cwd, check=True, capture_output=True, text=True)
    return completed.stdout.rstrip("\n").splitlines()


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def record(path: pathlib.Path) -> dict[str, int | str]:
    return {"sha256": sha256(path), "size_bytes": path.stat().st_size}


def main() -> None:
    preserved_pdf = ROOT / "snapshot/preconfirmatory_review.pdf"
    rebuilt_pdf = ROOT / "ec_v02.pdf"
    log_text = (ROOT / "ec_v02.log").read_text()
    with tempfile.TemporaryDirectory() as temp_dir:
        temp = pathlib.Path(temp_dir)
        preserved_text = temp / "preserved.txt"
        rebuilt_text = temp / "rebuilt.txt"
        subprocess.run(["pdftotext", preserved_pdf, preserved_text], check=True)
        subprocess.run(["pdftotext", rebuilt_pdf, rebuilt_text], check=True)
        text_matches = preserved_text.read_bytes() == rebuilt_text.read_bytes()

    source_paths = [
        ROOT / ".gitignore",
        ROOT / "Makefile",
        ROOT / "references.bib",
        ROOT / "snapshot/confirmatory_manifest.json",
        ROOT / "snapshot/create_manifest.py",
        ROOT / "snapshot/preconfirmatory_review.pdf",
        *sorted(path for path in (ROOT / "v02").rglob("*") if path.is_file()),
    ]
    manifest = {
        "schema_version": "0.1",
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "pre-confirmatory-outcomes-unobserved",
        "build_command": "make v02",
        "original_paper_tree": {
            "path": str(ORIGINAL_PAPER),
            "head": run("git", "rev-parse", "HEAD", cwd=ORIGINAL_PAPER),
            "status_porcelain": run_lines(
                "git", "status", "--porcelain=v1", "--untracked-files=all", cwd=ORIGINAL_PAPER
            ),
        },
        "protocol": {
            "protocol_commit": "da7d4f2a481514ea80bd1130dd3f9e2582a0444c",
            "protocol_tag": "v0.2-protocol-rc2",
            "protocol_tag_target": run(
                "git", "rev-list", "-n", "1", "v0.2-protocol-rc2", cwd=PROTOCOL_REPO
            ),
            "freeze_commit": "df320df9ab6265fff3cc8ca5b545fb317fd2e0a8",
            "freeze_tag": "v0.2-confirmatory-freeze-20260811",
            "freeze_tag_target": run(
                "git",
                "rev-list",
                "-n",
                "1",
                "v0.2-confirmatory-freeze-20260811",
                cwd=PROTOCOL_REPO,
            ),
            "freeze_parent": run(
                "git", "rev-parse", "df320df9ab6265fff3cc8ca5b545fb317fd2e0a8^", cwd=PROTOCOL_REPO
            ),
        },
        "build_verification": {
            "page_count": int(
                next(
                    line.split(":", 1)[1].strip()
                    for line in run("pdfinfo", "ec_v02.pdf", cwd=ROOT).splitlines()
                    if line.startswith("Pages:")
                )
            ),
            "preserved_pdf": record(preserved_pdf),
            "rebuilt_pdf": record(rebuilt_pdf),
            "extracted_text_matches": text_matches,
            "undefined_reference_warnings": "undefined references" in log_text,
            "overfull_box_warnings": "Overfull" in log_text,
        },
        "files": {
            str(path.relative_to(ROOT)): record(path)
            for path in source_paths
        },
    }
    output = ROOT / "snapshot/preconfirmatory_snapshot.json"
    output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
