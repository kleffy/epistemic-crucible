# v0.2 manuscript workspace

This tree is additive and does not modify the dirty v0.1 manuscript. It is anonymous
by construction and contains no author identity, email, repository username, or
claims based on results that have not been run.

Build the anonymous draft with the exact official ICLR 2027 style files using:

```bash
make v02
```

Before submission:

1. Keep the main text to nine pages.
2. Cite the public v0.1 prototype in the third person.
3. Fill results only from frozen confirmatory artifacts and preserve exact intervals.
4. Audit PDF metadata, source paths, supplement, Git history, and citation metadata.
5. Register the genuine abstract by 18 September 2026 AOE and submit the paper by
   25 September 2026 AOE.
